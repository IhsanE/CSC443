void random_array(char *array, long bytes);
int get_histogram( FILE *fp, long hist[], int block_size, long *milliseconds, long *total_bytes_read);
void compute_histogram(long *p_hist, char *p_buf,int size);
